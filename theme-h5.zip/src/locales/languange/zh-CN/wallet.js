// 中文语言包 - 钱包信息
export default {
  header: '钱包信息',
  tipsText: '尊敬的用户，为了保护您的账户资金，请不要在任何地方输入您的钱包密码。我们公司不会要求您提供钱包密码!',

  CurrencyName: '名称',
  Address: '钱包地址',
  PublicChain: '交易所',
  Name: '网络',

  PleaseEnter: '请输入',
  save: '保存',
};
