/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 17:18:01
 */
export default {
  EditProfile: '编辑个人资料',
  ProfileImage: '个人资料图片',
  username: '用户名',
  ChangeWithdrawalPassword: '修改提现密码',
  ChangeLoginPassword: '修改登录密码',

  changePassword: '修改密码',
  OldPassword: '旧密码',
  NewPassword: '新密码',
  ConfirmPassword: '确认密码',
  // 两次密码不一致
  PasswordInconsistent: '两次密码不一致',
};
