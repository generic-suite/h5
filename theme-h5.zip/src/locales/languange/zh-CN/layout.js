/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 13:00:20
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 13:00:44
 */
export default {
  HOME: '首页',
  START: '开始',
  RECORDS: '记录',
}