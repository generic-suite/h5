// 定义语言文件
export default {
  hello: '首页',
  Please_contact_customer_service: '请联系客服', 
};
