export default {
  deposit: '充值',
  TransactionHistory: '充值记录',
  DepositAmount: '充值金额',
  ContactSupport: '联系客服',
};
