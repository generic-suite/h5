export default {
  noMore: '没有更多了',
  loading: '加载中...',
  PleaseEnter: '请输入',
  Save: '保存',
  Submit: '提交',
};
