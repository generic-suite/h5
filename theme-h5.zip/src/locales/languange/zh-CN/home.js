/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-23 14:33:50
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 17:16:44
 */
export default {
  PROFILE: '',
  Announcement: '为您提供最专业的建议和信息...',
  welcomeBack: '嗨！欢迎回来',

  VIP: 'VIP',
  Recharge: '充值',
  Security: '安全',
  Withdraw: '提现',
  CONTACTUS: '联系我们',
  TermsConditions: '条款和条件',
  LatestEvent: '最新活动',
  Certificate: '证书',
  FAQ: '介绍',
  AboutUs: '关于我们',
};
