/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 10:26:26
 */
export default {
  ReferralCode: '推荐码',
  CreditScore: '信用分',
  TodaysCommission: '今日佣金',
  AccountBalance: '账户余额',
  PleaseEnterWithPassword: '请输入提现密码',
  Password: '密码',
  CopySuccess: '复制成功',
  WithdrawalPasswordError: '提现密码错误',

  Support: '支持',
  EditProfile: '编辑个人资料',
  Withdraw: '提现',
  WalletInfo: '钱包信息',
  Transaction: '交易',
  Logout: '退出登录',
};
