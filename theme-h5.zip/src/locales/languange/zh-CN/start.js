/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 13:55:13
 */
export default {
  start: '开始',
  StartRating: '开始评分',
  Starting: '进行中中',
  'TodaysProfits': '今日收益',
  'Profits_updated_automatically_system_every_day': '收益每日由系统自动更新',
  'Account_Balance': '账户余额',
  'Profits_product_added_account_balance': '每个产品的收益将添加到帐户余额中',
  'ImportantNotice': '重要通知',
  'OperationHours': '营业时间',
  'more_information_contact_customer_support': '更多信息，请联系客服',
  'OptimizationSubmission': '商品提交',
  'Total_amount': '总金额',
  'Profit': '利润',
  'Creation_time': '创建时间',
  'Data_No': '数据编号',
  'Submit': '提交',
};