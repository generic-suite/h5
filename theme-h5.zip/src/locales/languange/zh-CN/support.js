/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 09:15:23
 */
export default {
  ContactUs: '联系我们',
  ContactUsIfYouHaveAnyProblem: '',
  ContactUsVia: '如果您有任何问题需要咨询，请与我们联系',
  CustomerServiceHoursOfOperation: '客户服务工作时间',
  Unit: '',
};
