/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 13:55:13
 */
export default {
  myOrder: '我的订单',
  All: '全部',
  Pending: '待处理',
  Completed: '已完成',
  Reverted: '已撤销',
  Price: '价格',
  Total: '总计',
  TotalCommission: '总佣金',
  Submit: '提交',
  SubmittedSuccessfully: '提交成功',
};
