/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-20 11:29:10
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 11:33:19
 */
export default {
  noMore: 'Er is niets meer',
  loading: 'Laden...',
  PleaseEnter: 'Gelieve in te voeren',
  Save: 'bewaren',
  Submit: 'Verzenden',
  SubmittedSuccessfully: 'Succesvol ingediend',
};
