/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 12:05:18
 */
export default {
  EditProfile: 'Profiel bewerken',
  ProfileImage: 'Profielafbeelding',
  username: 'gebruikersnaam',
  ChangeWithdrawalPassword: 'Wachtwoord voor opname wijzigen',
  ChangeLoginPassword: 'Aanmeldwachtwoord wijzigen',

  changePassword: 'Wachtwoord wijzigen',
  OldPassword: 'Oud wachtwoord',
  NewPassword: 'Nieuw wachtwoord',
  ConfirmPassword: 'Wachtwoord bevestigen',
  // 两次密码不一致
  PasswordInconsistent: 'De twee wachtwoorden komen niet overeen',
};
