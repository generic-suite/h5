/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 11:31:51
 */
export default {
  myOrder: 'Mijn bestelling',
  All: 'geheel',
  Pending: 'behandeling',
  Completed: 'Voltooid',
  Reverted: 'ingetrokken',
  Price: 'prijs',
  Total: 'totaal',
  TotalCommission: 'Totale commissie',
  SubmittedSuccessfully: 'Succesvol ingediend',
};
