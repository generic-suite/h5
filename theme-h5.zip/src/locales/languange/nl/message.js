/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-20 11:29:10
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 11:36:35
 */
// 定义语言文件
export default {
  hello: 'startpagina',
  Please_contact_customer_service: 'Neem contact op met de klantenservice',
};
