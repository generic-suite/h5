/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 11:37:50
 */
export default {
  start: 'start',
  StartRating: 'Startbeoordeling',
  Starting: 'In uitvoering',
  TodaysProfits: 'De inkomsten van vandaag',
  Profits_updated_automatically_system_every_day: 'Inkomsten worden dagelijks automatisch bijgewerkt door het systeem',
  Account_Balance: 'Rekeningssaldo',
  Profits_product_added_account_balance:
    'De opbrengsten van elk product worden toegevoegd aan het saldo van de rekening',
  ImportantNotice: 'Belangrijke mededeling',
  OperationHours: 'Werkuren',
  more_information_contact_customer_support: 'Neem voor meer informatie contact op met de klantenservice',
  OptimizationSubmission: 'Product indiening',
  Total_amount: 'Totaal bedrag',
  Profit: 'winst',
  Creation_time: 'Aanmaaktijd',
  Data_No: 'Gegevensnummer',
  Submit: 'Verzenden',
};
