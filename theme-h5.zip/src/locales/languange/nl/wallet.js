// 中文语言包 - 钱包信息
export default {
  header: 'Wallet-informatie',
  tipsText:
    'Beste gebruiker, om uw rekeningtegoed te beschermen, voert u uw portemonnee wachtwoord nergens in. Ons bedrijf vereist geen wachtwoord voor uw portemonnee!',

  CurrencyName: 'Naam',
  Address: 'Portemonnee adres',
  PublicChain: 'Uitwisseling',
  Name: 'Netwerk',

  PleaseEnter: 'Gelieve in te voeren',
  save: 'bewaren',
};
