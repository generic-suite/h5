/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 09:16:37
 */
export default {
  ContactUs: 'Neem contact met ons op',
  ContactUsIfYouHaveAnyProblem: '',
  ContactUsVia: 'Als u vragen heeft die u moet raadplegen, neem dan contact met ons op',
  CustomerServiceHoursOfOperation: 'De werkuren van de klantenservice zijn van',
  Unit: '',
};
