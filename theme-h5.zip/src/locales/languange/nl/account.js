/*
 * @Descripttion: 荷兰语
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 10:26:18
 */
export default {
  ReferralCode: 'Aanbevelingscode',
  CreditScore: 'Krediet score',
  TodaysCommission: 'De commissie van vandaag',
  AccountBalance: 'Rekeningssaldo',
  PleaseEnterWithPassword: 'Voer het opnamewachtwoord in',
  Password: 'wachtwoord',
  CopySuccess: 'Succesvol gekopieerd',
  WithdrawalPasswordError: 'Fout bij het intrekken van wachtwoord',

  Support: 'ondersteuning',
  EditProfile: 'Profiel bewerken',
  Withdraw: 'Terugtrekking',
  WalletInfo: 'Wallet-informatie',
  Transaction: 'transactie',
  Logout: 'Afmelden',
};
