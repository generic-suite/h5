/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 15:28:10
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 15:29:35
 */
export default {
  header: 'Transactiegeschiedenis',
};
