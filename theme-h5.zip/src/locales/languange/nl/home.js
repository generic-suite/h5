export default {
  PROFILE: '',
  Announcement: 'U voorzien van het meest professionele advies en informatie...',
  welcomeBack: 'Hoi! Welkom terug',

  VIP: 'VIP',
  Recharge: 'Opladen',
  Security: 'beveiliging',
  Withdraw: 'Terugtrekking',
  CONTACTUS: 'Neem contact met ons op',
  TermsConditions: 'Algemene voorwaarden',
  LatestEvent: 'Laatste gebeurtenissen',
  Certificate: 'certificaat',
  FAQ: 'FAQ',
  AboutUs: 'Over ons',
};
