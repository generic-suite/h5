/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 13:00:20
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 11:34:44
 */
export default {
  HOME: 'startpagina',
  START: 'start',
  RECORDS: 'record',
};