/*
 * @Descripttion: 
 * @Author: Harley
 * @Date: 2023-12-05 10:25:41
 * @LastEditors: Harley
 * @LastEditTime: 2023-12-05 10:40:20
 */
// 中文语言包 - 钱包信息
export default {
  CashWithdrawal: 'Terugtrekking',
  WithdrawalHistory: 'Opnamegegevens',
  AccountBalance: 'Rekeningssaldo',
  WithdrawTime: 'De opname zal binnen een uur worden verwerkt',
  withdrawalAddress1: 'Uw opname wordt overgebracht naar uw cryptocurrency USDT wallet',
  withdrawalAddress2: 'Uw opname wordt overgebracht naar uw WISE-account (USD)',
  WithdrawalTimeLimit: 'De herroepingstermijn is',
  WithdrawalTimeUnit: '',
  WithdrawAmount: 'Opnamebedrag',
  WithdrawPassword: 'Wachtwoord voor intrekking',
  Withdraw: 'Terugtrekking',
  YouHaveTotSetUpYourWalletAddress: 'Je hebt nog geen portemonnee adres ingesteld',
  NoTransactionHistory: 'Geen transactiegeschiedenis',
};
