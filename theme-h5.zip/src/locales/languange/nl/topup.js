/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-20 11:29:10
 * @LastEditors: harley
 * @LastEditTime: 2023-10-20 11:38:28
 */
export default {
  deposit: 'Opladen',
  TransactionHistory: 'Oplaadrecord',
  DepositAmount: 'Oplaadbedrag',
  ContactSupport: 'Neem contact op met de klantenservice',
};
