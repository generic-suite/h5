/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 09:16:48
 */
export default {
  ContactUs: 'Kontaktiere uns',
  ContactUsIfYouHaveAnyProblem: '',
  ContactUsVia: 'Wenn sie rat zu weiteren fragen benötigen, wenden sie sich bitte an uns',
  CustomerServiceHoursOfOperation: 'Öffnungszeiten des Kundendienstes: ',
  Unit: 'Uhr',
};
