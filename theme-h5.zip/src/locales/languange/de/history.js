/*
 * @Descripttion: 德语语言包
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 14:08:02
 */
export default {
  myOrder: 'Meine Bestellung',
  All: 'Alle',
  Pending: 'Ausstehend',
  Completed: 'Abgeschlossen',
  Reverted: 'Zurückgezogen',
  Price: 'Preis',
  Total: 'Gesamt',
  TotalCommission: 'Gesamtprovision',
  Submit: 'einreichen',
  SubmittedSuccessfully: 'Erfolgreich eingereicht',
};
