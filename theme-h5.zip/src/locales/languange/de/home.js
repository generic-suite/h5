/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 12:55:50
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 12:57:25
 */
export default {
  PROFILE: '',
  Announcement: 'Wir bieten Ihnen professionelle Beratung und Informationen...',
  welcomeBack: 'Hallo! Willkommen zurück',

  VIP: 'VIP',
  Recharge: 'Aufladen',
  Security: 'Sicherheit',
  Withdraw: 'Rückzug',
  CONTACTUS: 'KONTAKTIEREN SIE UNS',
  TermsConditions: 'Allgemeine Geschäftsbedingungen',
  LatestEvent: 'Latest Event',
  Certificate: 'Zertifikat',
  FAQ: 'FAQ',
  AboutUs: 'über uns',
};
