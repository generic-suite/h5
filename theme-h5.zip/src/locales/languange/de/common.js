/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 15:35:28
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 17:20:39
 */
// 德语语言包
export default {
  noMore: 'Keine mehr',
  loading: 'Wird geladen...',
  PleaseEnter: 'Bitte eingeben',
  Save: 'Speichern',
  Submit: 'Einreichen',
};
