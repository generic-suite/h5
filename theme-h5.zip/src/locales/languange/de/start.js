/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 13:49:44
 */
export default {
  start: 'start',
  StartRating: 'StartRating',
  Starting: 'Starting',
  TodaysProfits: 'Der heutige Gewinn',
  Profits_updated_automatically_system_every_day: 'Gewinne werden täglich automatisch vom System aktualisiert',
  Account_Balance: 'Kontostand',
  Profits_product_added_account_balance: 'Gewinne aus jedem Produkt werden dem Kontostand hinzugefügt',
  ImportantNotice: 'Wichtiger Hinweis',
  OperationHours: 'Betriebszeiten',
  more_information_contact_customer_support: 'Für weitere Informationen wenden Sie sich bitte an den Kundendienst',
  OptimizationSubmission: 'Einreichung von Optimierungen',
  Total_amount: 'Gesamtbetrag',
  Profit: 'Profit',
  Creation_time: 'Zeit bei der Erstellung',
  Data_No: 'Daten Nr.',
  Submit: 'Unterwerfen',
};