// 德语语言包-钱包信息
export default {
  header: 'Wallet Informationen',
  tipsText:
    'Sehr geehrter Benutzer, um Ihr Guthaben zu schützen, geben Sie bitte Ihr Wallet-Passwort nirgendwo ein. Unser Unternehmen verlangt nicht, dass Sie ein Wallet-Passwort angeben!',

  CurrencyName: 'Name',
  Address: 'Wallet-Adresse',
  PublicChain: 'Austausch',
  Name: 'Netzwerk',

  PleaseEnter: 'Bitte geben Sie ein',
  save: 'Speichern',
};
