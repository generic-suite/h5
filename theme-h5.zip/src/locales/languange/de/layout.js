/*
 * @Descripttion: 德语语言包
 * @Author: harley
 * @Date: 2023-10-17 13:00:20
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 13:02:24
 */
export default {
  HOME: 'Startseite Seite',
  START: 'START',
  RECORDS: 'Aufnehmen',
};
