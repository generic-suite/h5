/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 23:11:03
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 23:11:08
 */
// 德语语言包
export default {
  deposit: 'Aufladen',
  TransactionHistory: 'Aufladungsaufzeichnung',
  DepositAmount: 'Aufladebetrag',
  ContactSupport: 'Kundendienst kontaktieren',
};
