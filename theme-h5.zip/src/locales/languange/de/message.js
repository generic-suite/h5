/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 10:17:24
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 11:43:22
 */
// 定义语言文件-德语
export default {
  hallp: 'home',
  Please_contact_customer_service: 'Bitte kontaktieren Sie den Kundenservice',
};
