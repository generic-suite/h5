/*
 * @Descripttion: 德语语言包
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 17:19:51
 */
export default {
  EditProfile: 'Profil bearbeiten',
  ProfileImage: 'Profilbild',
  username: 'Nutzername',
  ChangeWithdrawalPassword: 'Abhebungspasswort ändern',
  ChangeLoginPassword: 'Anmeldepasswort ändern',

  OldPassword: 'Altes Passwort',
  NewPassword: 'Neues Kennwort',
  ConfirmPassword: 'Bestätige das Passwort',
};
