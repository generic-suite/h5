// 英语语言包
export default {
  noMore: 'No more',
  loading: 'Loading...',
  PleaseEnter: 'Please enter',
  Save: 'Save',
  Submit: 'Submit',
};
