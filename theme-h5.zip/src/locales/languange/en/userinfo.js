/*
 * @Descripttion: 英语语言包
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 15:50:24
 */
export default {
  EditProfile: 'Edit Profile',
  ProfileImage: 'Profile Image',
  username: 'Username',
  ChangeWithdrawalPassword: 'Change security pin',
  ChangeLoginPassword: 'Change Login Password',

  OldPassword: 'Old Password',
  NewPassword: 'New Password',
  ConfirmPassword: 'Confirm Password',
};
