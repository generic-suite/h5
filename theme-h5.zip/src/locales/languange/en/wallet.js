/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-23 14:33:50
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 17:06:41
 */
// 英语语言包-钱包信息
export default {
  header: 'Withdrawal Details',
  tipsText:
    'Dear user, in order to protect your funds in your account, please not to enter your wallet password. Our company will not ask for your wallet password!',

  CurrencyName: 'Name',
  Address: 'Wallet Address',
  PublicChain: 'Exchange',
  Name: 'Network',
  wise_mail: 'WISE Mail',
  wise_user: 'WISE User',

  PleaseEnter: 'Please enter',
  save: 'Save',
};
