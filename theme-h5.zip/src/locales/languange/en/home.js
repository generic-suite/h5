/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-23 14:33:50
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 17:22:33
 */
export default {
  PROFILE: '',
  Announcement: 'Providing you with the most professional advice and information...',
  welcomeBack: 'Hi! Welcome Back',

  VIP: 'VIP',
  Recharge: 'WITHDRAW DETAILS',
  Security: 'Security',
  Withdraw: 'WITHDRAW',
  CONTACTUS: 'CONTACT US',
  TermsConditions: 'T&C',
  LatestEvent: 'LATEST EVENT',
  Certificate: 'Certificate',
  FAQ: 'FAQ',
  AboutUs: 'ABOUT US',
};
