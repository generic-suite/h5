/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 10:17:24
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 11:30:19
 */
// 定义语言文件
export default {
  hello: 'home',
  Please_contact_customer_service: 'Please contact customer service',
};
