/*
 * @Descripttion: 英语语言包
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 10:26:01
 */
export default {
  ReferralCode: 'Referral Code',
  CreditScore: 'Credit Score',
  TodaysCommission: "Today's Earnings",
  AccountBalance: 'Account Balance',
  PleaseEnterWithPassword: 'Please enter the security pin',
  Password: 'Password',
  CopySuccess: 'Copy Success',
  WithdrawalPasswordError: 'security pin error',

  Support: 'Contact Us',
  EditProfile: 'Edit Profile',
  Withdraw: 'Withdraw',
  WalletInfo: 'Withdrawal Details',
  Transaction: 'Transaction',
  Logout: 'Logout',
};
