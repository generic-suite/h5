// 英文语言包
export default {
  deposit: 'Deposit',
  TransactionHistory: 'Transaction History',
  DepositAmount: 'Deposit Amount',
  ContactSupport: 'Contact Support',
};
