/*
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 09:28:09
 */
export default {
  start: 'start',
  StartRating: 'START PROMOTE',
  Starting: 'Starting',
  TodaysProfits: "Today's Earnings",
  Profits_updated_automatically_system_every_day: 'Earnings are updated automatically by the system every day',
  Account_Balance: 'Account Balance',
  Profits_product_added_account_balance: 'Earnings from each product will be added to the account balance.',
  ImportantNotice: 'Important Notice',
  OperationHours: 'Operation Hours',
  more_information_contact_customer_support: 'For more information, please contact customer support',
  OptimizationSubmission: 'Promote Submission',
  Total_amount: 'Total amount',
  Profit: 'Earning',
  Creation_time: 'Creation time',
  Data_No: 'Data No.',
  Submit: 'Submit',
};