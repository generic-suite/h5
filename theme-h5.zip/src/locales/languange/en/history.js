/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-17 14:02:39
 */
export default {
  myOrder: 'my Order',
  All: 'All',
  Pending: 'Pending',
  Completed: 'Completed',
  Reverted: 'Freezed',
  Price: 'Price',
  Total: 'Total',
  TotalCommission: 'Total Commission',
  Submit: 'Submit',
  SubmittedSuccessfully: 'Submitted Successfully',
};
