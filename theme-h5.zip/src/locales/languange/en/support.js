/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-17 13:41:48
 * @LastEditors: harley
 * @LastEditTime: 2023-10-24 09:14:59
 */
export default {
  ContactUs: 'Contact us',
  ContactUsIfYouHaveAnyProblem: '',
  ContactUsVia: 'Contact us if you have any problem need to be inquired',
  CustomerServiceHoursOfOperation: 'Online Support Operation Hour is ',
  Unit: '',
};
