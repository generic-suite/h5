<!--
 * @Descripttion: 
 * @Author: harley
 * @Date: 2023-10-05 09:58:37
 * @LastEditors: harley
 * @LastEditTime: 2023-10-05 09:58:39
-->
<template>
  <div>
    <h1>首页</h1>
  </div>
</template>

<script setup>
import { ref, reactive, computed, watch, onMounted, onUnmounted } from 'vue';
const count = ref(0);
</script>

<style scoped lang="scss"></style>
