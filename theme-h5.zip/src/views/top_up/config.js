export const list = [
  {
    value: '100',
  },
  {
    value: '500',
  },
  {
    value: '1000',
  },
  {
    value: '5000',
  },
  {
    value: '10000',
  },
  {
    value: '30000',
  },
];

