/*
 * @Descripttion:
 * @Author: harley
 * @Date: 2023-10-05 13:57:02
 * @LastEditors: harley
 * @LastEditTime: 2023-11-01 15:57:44
 */
import request from '@/utils/axios.js';

export const photoListData = [
  { url: '/img/01.png' },
  { url: '/img/02.png' },
  { url: '/img/03.png' },
  { url: '/img/04.png' },
  { url: '/img/05.png' },
  { url: '/img/06.png' },
  { url: '/img/07.png' },
  { url: '/img/08.png' },
  { url: '/img/09.png' },
  { url: '/img/010.png' },
  { url: '/img/011.png' },
  { url: '/img/012.png' },
  { url: '/img/013.png' },
  { url: '/img/014.png' },
  { url: '/img/015.png' },
];
